"""Command-line prototype of the Offline Learning Companion.

    python -m olc.cli ask "slope of the tangent line"
    python -m olc.cli plan --state data/sample_state.json --today 7
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

from .retrieval import TfidfIndex
from .scheduler import next_interval, recall_probability

ROOT = Path(__file__).resolve().parent.parent
NOTES_PATH = ROOT / "data" / "notes.json"


def load_notes(path: Path = NOTES_PATH) -> list[dict]:
    with open(path, encoding="utf-8") as fh:
        return json.load(fh)["notes"]


def cmd_ask(args) -> int:
    notes = load_notes()
    index = TfidfIndex().fit([n["title"] + ". " + n["text"] for n in notes])
    hits = [(i, s) for i, s in index.search(args.question, args.k) if s > 0]
    if not hits:
        print("No matching note found in your offline notes.")
        return 1
    for rank, (i, score) in enumerate(hits, 1):
        print(f"{rank}. {notes[i]['title']}  (similarity {score:.2f})")
        print(f"   {notes[i]['text']}\n")
    return 0


def cmd_plan(args) -> int:
    with open(args.state, encoding="utf-8") as fh:
        state = json.load(fh)
    rows = []
    for item in state:
        elapsed = args.today - item["last_review_day"]
        p = float(recall_probability(elapsed, item["S_est"]))
        due_in = item["last_review_day"] + next_interval(item["S_est"], args.target) - args.today
        rows.append((p, due_in, item["concept"]))
    rows.sort()
    print(f"Review plan for day {args.today:g} (target recall {args.target:.0%})")
    print(f"{'Concept':28s} {'Recall now':>10s}  Status")
    for p, due_in, name in rows:
        status = "REVIEW NOW" if due_in <= 0 else f"due in {due_in:.1f} d"
        print(f"{name:28s} {p:10.0%}  {status}")
    return 0


def build_parser() -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser(prog="olc", description="Offline Learning Companion")
    sub = ap.add_subparsers(dest="cmd", required=True)
    a = sub.add_parser("ask", help="search your notes offline")
    a.add_argument("question")
    a.add_argument("--k", type=int, default=3)
    a.set_defaults(func=cmd_ask)
    p = sub.add_parser("plan", help="which concepts to review now")
    p.add_argument("--state", default=str(ROOT / "data" / "sample_state.json"))
    p.add_argument("--today", type=float, default=7.0)
    p.add_argument("--target", type=float, default=0.85)
    p.set_defaults(func=cmd_plan)
    return ap


def main(argv=None) -> int:
    args = build_parser().parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
