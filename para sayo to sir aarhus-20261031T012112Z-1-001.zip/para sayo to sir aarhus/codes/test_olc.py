import json
import unittest
from pathlib import Path

import numpy as np

from olc.forgetting import fit_gradient_descent, fit_newton, gradient, hessian, objective
from olc.retrieval import TfidfIndex, light_stem, tokenize
from olc.scheduler import next_interval, recall_probability, update_strength
from olc.simulate import calibration_reviews

ROOT = Path(__file__).resolve().parent.parent


class TestForgetting(unittest.TestCase):
    def setUp(self):
        self.t, self.y = calibration_reviews(5.0, 80, np.random.default_rng(1))

    def test_gradient_matches_finite_difference(self):
        for th in (-2.0, -1.0, 0.0):
            h = 1e-5
            fd = (objective(th + h, self.t, self.y) - objective(th - h, self.t, self.y)) / (2 * h)
            self.assertAlmostEqual(gradient(th, self.t, self.y), fd, places=6)

    def test_hessian_matches_finite_difference(self):
        for th in (-2.0, -1.0, 0.0):
            h = 1e-5
            fd = (gradient(th + h, self.t, self.y) - gradient(th - h, self.t, self.y)) / (2 * h)
            self.assertAlmostEqual(hessian(th, self.t, self.y), fd, places=6)

    def test_methods_agree(self):
        a = fit_newton(self.t, self.y, tol=1e-10)
        b = fit_gradient_descent(self.t, self.y, step=1.0, tol=1e-10)
        self.assertTrue(a.converged and b.converged)
        self.assertAlmostEqual(a.strength, b.strength, places=5)
        self.assertLess(a.iterations, b.iterations)

    def test_recovers_strength_with_many_samples(self):
        t, y = calibration_reviews(5.0, 5000, np.random.default_rng(7))
        self.assertAlmostEqual(fit_newton(t, y).strength / 5.0, 1.0, delta=0.15)

    def test_objective_never_increases_for_newton(self):
        h = fit_newton(self.t, self.y).objective_history
        self.assertTrue(all(b <= a + 1e-12 for a, b in zip(h, h[1:])))

    def test_all_success_hits_bound_without_crash(self):
        r = fit_newton(np.array([1.0, 2.0, 3.0]), np.array([1, 1, 1]))
        self.assertTrue(r.hit_bound)


class TestScheduler(unittest.TestCase):
    def test_interval_formula(self):
        self.assertAlmostEqual(next_interval(10.0, 0.85), -10.0 * np.log(0.85), places=9)

    def test_recall_at_interval_equals_target(self):
        s = 6.0
        self.assertAlmostEqual(float(recall_probability(next_interval(s, 0.8), s)), 0.8, places=9)

    def test_invalid_target(self):
        with self.assertRaises(ValueError):
            next_interval(5.0, 1.0)

    def test_strength_update_direction(self):
        self.assertGreater(update_strength(4.0, True), 4.0)
        self.assertLess(update_strength(4.0, False), 4.0)


class TestRetrieval(unittest.TestCase):
    def test_stem_consistency(self):
        self.assertEqual(light_stem("rates"), light_stem("rate"))
        self.assertEqual(light_stem("scheduling"), light_stem("schedule"))

    def test_stopwords_removed(self):
        self.assertNotIn("the", tokenize("the slope of the line"))

    def test_search_finds_note_and_is_deterministic(self):
        with open(ROOT / "data" / "notes.json", encoding="utf-8") as fh:
            notes = json.load(fh)["notes"]
        idx = TfidfIndex().fit([n["title"] + ". " + n["text"] for n in notes])
        first = idx.search("slope of the tangent line", 3)
        self.assertEqual(notes[first[0][0]]["title"], "Derivative")
        self.assertEqual(first, idx.search("slope of the tangent line", 3))

    def test_unknown_query_scores_zero(self):
        idx = TfidfIndex().fit(["alpha beta", "gamma delta"])
        self.assertTrue(np.all(idx.scores("zzz qqq") == 0))


if __name__ == "__main__":
    unittest.main()
