"""Offline Learning Companion (OLC): memory-decay modeling, spaced-repetition
scheduling, and local TF-IDF retrieval. Uses only NumPy; no network access."""

__version__ = "1.0.0"
