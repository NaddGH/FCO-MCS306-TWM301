"""Synthetic learner used for the experiments (no real student data is used)."""
from __future__ import annotations

import numpy as np

from .scheduler import next_interval, recall_probability, update_strength


def draw_true_strengths(n_concepts: int, rng: np.random.Generator, median=4.0, sigma=0.6) -> np.ndarray:
    """Log-normal memory strengths in days (median 4 d)."""
    return median * np.exp(sigma * rng.standard_normal(n_concepts))


def calibration_reviews(strength: float, n: int, rng: np.random.Generator, t_lo=0.25, t_hi=21.0):
    """n review attempts at log-uniform delays; outcomes ~ Bernoulli(exp(-t/S))."""
    t = np.exp(rng.uniform(np.log(t_lo), np.log(t_hi), n))
    y = (rng.random(n) < recall_probability(t, strength)).astype(int)
    return t, y


def run_policy(s_true0: float, rng: np.random.Generator, horizon: float = 90.0,
               fixed_interval: float | None = None, s_est0: float | None = None,
               target: float = 0.85):
    """Simulate one concept. Returns (reviews, recalled, retention_at_horizon)."""
    s_true = s_true0
    s_est = s_est0
    t_last, reviews, recalled = 0.0, 0, 0
    interval = fixed_interval if fixed_interval is not None else next_interval(s_est, target)
    t = interval
    while t < horizon:   # reviews strictly before the day-90 exam
        ok = bool(rng.random() < recall_probability(t - t_last, s_true))
        reviews += 1
        recalled += ok
        s_true = update_strength(s_true, ok)
        if fixed_interval is None:
            s_est = update_strength(s_est, ok)
            interval = next_interval(s_est, target)
        else:
            interval = fixed_interval
        t_last = t
        t += interval
    retention = float(recall_probability(horizon - t_last, s_true))
    return reviews, recalled, retention
